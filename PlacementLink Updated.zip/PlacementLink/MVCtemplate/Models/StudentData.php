<?php
class StudentData {
    private $_id, $_email, $_password;

    public function __construct($dbRow) {


        $this->_id = $dbRow['student_id'];
        $this->_email = $dbRow['email'];
        $this->_password = $dbRow['password'];
    }

    public function getStudentID() {
        return $this->_id;
    }

    public function getEmail() {
        return $this->_email;
    }

    public function getPassword() {
        return $this->_password;
    }

    public function checkPassword($password){
        if(password_verify($password, $this->_password)){
            return true;
        }else if($password == $this->_password){
            return true;
        }
        else{
            return false;
        }
    }
}


