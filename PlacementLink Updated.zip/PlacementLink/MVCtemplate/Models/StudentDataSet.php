<?php
require_once ('Models/Database.php');
require('Models/StudentData.php');

class UserDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAllUsers()
    {
        $sqlQuery = "SELECT * FROM Student";

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new studentData($row);
        }
        return $dataSet;
    }

//    public function searchUser($field, $value)
//    {
//        $sqlQuery = "SELECT * FROM members WHERE $field = '$value'";
//
//        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
//        $statement->execute(); // execute the PDO statement
//
////        $dataSet;
//        while ($row = $statement->fetch()) {
//            $dataSet = new userData($row);
//        }
//        return $dataSet;
//    }


    public function insertStudent($post)
    {
//        $firstName = $post['first_name'];
//        $lastName = $post['last_name'];
//        $address = $post['address'];
//        $mobileNumber = $post['mobile_number'];
        $email = $post['email'];

        if(isset($post['password'])) {
            $password = password_hash($post['password'], PASSWORD_DEFAULT);
        }


        $sqlQuery = "INSERT INTO Student (email, password)
        VALUES('$email', '$password')";
        if ($this->_dbHandle->exec($sqlQuery)) {
            //$_SESSION['id'] = $this->_dbHandle->lastInsertId();
            $_SESSION['email'] = $email;
            return true;
            //echo "<script type='text/javascript'>alert('You have succesfully registered')</script>";

        } else {
            //echo "<script type='text/javascript'>alert('You have to fill out all fields')</script>";

        } // prepare a PDO statement


    }




//    public function searchMember($id)
//    {
//        $sqlQuery = "SELECT * FROM members WHERE member_id = '$id'";
//
//        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
//        $statement->execute(); // execute the PDO statement
//
//        while ($row = $statement->fetch()) {
//            $dataSet = new userData($row);
//        }
//        return $dataSet;
//    }

//    public function UpdateDetails($post)
//    {
//        $id = $_SESSION['id'];
//        $firstName = $post['first_name'];
//        $lastName = $post['last_name'];
//        $address = $post['address'];
//        $mobileNumber = $post['mobile_number'];
//        $email = $post['email'];
//        $password = $post['password'];
//
//        $sqlQuery = "UPDATE members set first_name = '$firstName', last_name = '$lastName',
//        address = '$address', mobile_number = '$mobileNumber', email = '$email', password = '$password'
//        WHERE member_id = '$id'";
//
//        if($statement = $this->_dbHandle->exec($sqlQuery)) // prepare a PDO statement
//        {
//            return true;
//        }
//        else {
//            return false;
//        }


//    }





//    Sanitize() function removes any potential threat from the
//    data submitted. Prevents email injections or any other hacker attempts.
//    if $remove_nl is true, newline chracters are removed from the input.
//    */
//    public function Sanitize($str,$remove_nl=true)
//    {
//        $str = $this->StripSlashes($str);
//
//        if($remove_nl)
//        {
//            $injections = array('/(\n+)/i',
//                '/(\r+)/i',
//                '/(\t+)/i',
//                '/(%0A+)/i',
//                '/(%0D+)/i',
//                '/(%08+)/i',
//                '/(%09+)/i'
//            );
//            $str = preg_replace($injections,'',$str);
//        }
//
//        return $str;
//    }
//
//      public function StripSlashes($str)
//      {
//          if(get_magic_quotes_gpc())
//          {
//              $str = stripslashes($str);
//          }
//          return $str;
//      }



}

