<?php
class StudentData
{
    private $_id, $_salary, $_name, $_description;

    public function __construct($dbRow)
    {


        $this->_id = $dbRow['placement_id'];
        $this->_salary = $dbRow['placement_sal'];
        $this->_name = $dbRow['placement_name'];
        $this->_description = $dbRow['placement_desc'];

    }


    public function getId()
    {
        return $this->_id;
    }


    public function getSalary()
    {
        return $this->_salary;
    }


    public function getName()
    {
        return $this->_name;
    }


    public function getDescription()
    {
        return $this->_description;
    }

}

